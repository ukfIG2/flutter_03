import '../models/quiz_question.dart';

// Prvá odpoveď v zozname je vždy správna, na obrazovke sa odpovede miešajú.
const questions = [
  QuizQuestion('Kto je otcom Luka Skywalkera?', [
    'Anakin Skywalker',
    'Obi-Wan Kenobi',
    'Owen Lars',
    'Han Solo',
  ]),
  QuizQuestion('Na ktorej planéte vyrastal Luke Skywalker?', [
    'Tatooine',
    'Naboo',
    'Hoth',
    'Endor',
  ]),
  QuizQuestion('Akú farbu má svetelný meč, ktorý používa Mace Windu?', [
    'Fialovú',
    'Zelenú',
    'Modrú',
    'Červenú',
  ]),
  QuizQuestion('Ako sa volá loď Hana Sola?', [
    'Millennium Falcon',
    'Slave I',
    'Tantive IV',
    'Razor Crest',
  ]),
  QuizQuestion('Kto trénoval Luka na planéte Dagobah?', [
    'Yoda',
    'Plo Koon',
    'Qui-Gon Jinn',
    'Mace Windu',
  ]),
  QuizQuestion('Ako sa volá Wookiee, ktorý lieta s Hanom Solom?', [
    'Chewbacca',
    'Tarfful',
    'Lowbacca',
    'Zaalbar',
  ]),
  QuizQuestion(
    'Ktorý droid ovláda viac ako šesť miliónov foriem komunikácie?',
    ['C-3PO', 'R2-D2', 'BB-8', 'K-2SO'],
  ),
  QuizQuestion('Ktorú planétu zničila Hviezda smrti v Epizóde IV?', [
    'Alderaan',
    'Coruscant',
    'Kashyyyk',
    'Mustafar',
  ]),
  QuizQuestion('Kto zabil Hana Sola v Epizóde VII?', [
    'Kylo Ren',
    'Darth Vader',
    'Boba Fett',
    'Snoke',
  ]),
  QuizQuestion('Ktorý rozkaz prikázal klonom zabiť Jediov?', [
    'Rozkaz 66',
    'Rozkaz 33',
    'Rozkaz 77',
    'Rozkaz 13',
  ]),
  QuizQuestion('Na ktorej ľadovej planéte mali rebeli základňu v Epizóde V?', [
    'Hoth',
    'Endor',
    'Bespin',
    'Dagobah',
  ]),
  QuizQuestion('Kto zabil Qui-Gona Jinna?', [
    'Darth Maul',
    'Gróf Dooku',
    'Generál Grievous',
    'Jango Fett',
  ]),
];
